export {default as foo} from "./src/foo";
